package com.board.comment.action;

public class CommentWriteAction {

}
