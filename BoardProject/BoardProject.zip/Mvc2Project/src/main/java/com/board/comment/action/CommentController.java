package com.board.comment.action;

public class CommentController {

}
